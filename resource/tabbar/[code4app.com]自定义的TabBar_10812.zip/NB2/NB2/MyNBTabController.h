//
//  MyNBTabController.h
//  NB2
//
//  Created by kohn on 13-11-16.
//  Copyright (c) 2013年 Kohn. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MyNBTabButton;
@interface MyNBTabController : UIViewController
@property (nonatomic,strong) MyNBTabButton *tabBarButton;
@end
