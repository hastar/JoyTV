//
//  Constants.m
//  KYArcTabDemo
//
//  Created by Kjuly on 1/8/13.
//  Copyright (c) 2013 Kjuly. All rights reserved.
//

#import "Constants.h"

@implementation Constants

@end
