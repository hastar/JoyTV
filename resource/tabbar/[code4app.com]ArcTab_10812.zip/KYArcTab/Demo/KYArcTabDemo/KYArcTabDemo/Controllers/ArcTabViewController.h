//
//  ArcTabViewController.h
//  KYArcTabDemo
//
//  Created by Kjuly on 1/9/13.
//  Copyright (c) 2013 Kjuly. All rights reserved.
//

#import "KYArcTabViewController.h"

@interface ArcTabViewController : KYArcTabViewController

@end
